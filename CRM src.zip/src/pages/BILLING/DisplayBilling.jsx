import React from 'react'
export default function DisplayBilling(){
    return(
        <>Billing data Details</>
    )
}