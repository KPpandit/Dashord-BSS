import { Grid } from '@mui/material'
import React, { Component } from 'react'
export default function LineChanges(){
    return(
        <> <Grid container spacing={1} sx={{width:450}}></Grid></>
    )
}